document.addEventListener('DOMContentLoaded', function() {
  const btnImport = document.getElementById('btnMouserImport'); // bottone import
  const codiceInput = document.getElementById('codice_prodotto');

  const fieldNamesMap = {
    partNumber: "Codice prodotto",
    manufacturer: "Costruttore",
    mouserSku: "Codice Fornitore",
    datasheet: "Datasheet",
    description: "Descrizione/Note",
    mouser_image: "Immagine",
    mouser_datasheet: "Datasheet Mouser"
  };

  const fieldToInputName = {
    partNumber: "codice_prodotto",
    manufacturer: "costruttore",
    mouserSku: "codice_fornitore",
    datasheet: "datasheet_url",
    description: "notes",
    
  };

  function createPopup(data) {
    let existing = document.getElementById('mouserModal');
    if (existing) existing.remove();

    const overlay = document.createElement('div');
    overlay.id = 'mouserModal';
    overlay.style.cssText = `
      position: fixed; top: 0; left: 0; width: 100%; height: 100%;
      background-color: rgba(0,0,0,0.5); display: flex;
      justify-content: center; align-items: center; z-index: 1000;
    `;

    const popup = document.createElement('div');
    popup.style.cssText = `
      background-color: #fff; 
      border-radius: 12px; 
      box-shadow: 0 4px 20px rgba(0,0,0,0.2);
      padding: 20px; 
      width: 800px;          /* <-- larghezza del popup */
      max-height: 80vh;       /* <-- altezza massima del popup */
      overflow-x: auto;       /* <-- scroll orrizzontale se il contenuto supera la larghezza */
      position: relative;
      font-family: Arial, sans-serif;
`;


    const btnClose = document.createElement('button');
    btnClose.textContent = '×';
    btnClose.style.cssText = `
      position: absolute; top: 10px; right: 15px; background: transparent;
      border: none; font-size: 22px; cursor: pointer;
    `;
    btnClose.addEventListener('click', () => overlay.remove());
    popup.appendChild(btnClose);

    const title = document.createElement('h4');
    title.textContent = 'Importa dati Mouser';
    title.style.textAlign = 'center';
    title.style.marginBottom = '15px';
    popup.appendChild(title);

    // messaggio guida per i file
    const guide = document.createElement('p');
    guide.textContent = 'Per immagine e datasheet, scarica i file e poi usa "Scegli file" in Aggiungi componente.';
    guide.style.fontSize = '12px';
    guide.style.color = '#555';
    guide.style.marginBottom = '10px';
    popup.appendChild(guide);

    const table = document.createElement('table');
    table.style.width = '100%';
    table.style.borderCollapse = 'collapse';

    const thead = document.createElement('thead');
    thead.innerHTML = `
      <tr>
        <th style="text-align:center;padding:5px;">Importa</th>
        <th style="text-align:left;padding:5px;">Campo</th>
        <th style="text-align:left;padding:5px;">Valore</th>
      </tr>
    `;
    table.appendChild(thead);

    const tbody = document.createElement('tbody');
    for (const key in data) {
      if (!data.hasOwnProperty(key)) continue;

      const tr = document.createElement('tr');
      tr.style.borderBottom = '1px solid #ddd';
      tr.style.height = '35px';

    const tdCheckbox = document.createElement('td');
    tdCheckbox.style.textAlign = 'center';

      if (key !== 'mouser_image' && key !== 'mouser_datasheet') {
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.checked = true;
        checkbox.dataset.field = key;
        tdCheckbox.appendChild(checkbox);
      }

      const tdCampo = document.createElement('td');
      tdCampo.textContent = fieldNamesMap[key] || key;
      tdCampo.style.paddingLeft = '5px';

      const tdValore = document.createElement('td');
      tdValore.style.paddingLeft = '5px';

      // gestione link download
      if ((key === 'mouser_image' || key === 'mouser_datasheet') && data[key]) {
        const link = document.createElement('a');
        link.href = data[key];
        link.textContent = key === 'mouser_image' ? 'Scarica immagine' : 'Scarica datasheet';
        link.target = '_blank';
        tdValore.appendChild(link);
      } else {
        tdValore.textContent = Array.isArray(data[key]) ? data[key].join(', ') : data[key] ?? '';
      }

      tr.appendChild(tdCheckbox);
      tr.appendChild(tdCampo);
      tr.appendChild(tdValore);
      tbody.appendChild(tr);
    }

    table.appendChild(tbody);
    popup.appendChild(table);

    const btnConfirm = document.createElement('button');
    btnConfirm.textContent = 'Importa selezionati';
    btnConfirm.style.cssText = `
      margin-top: 15px; background-color: #2a52f2; color: #fff;
      border: none; border-radius: 5px; padding: 8px 15px; cursor: pointer;
      font-size: 14px;
    `;

    btnConfirm.addEventListener('click', () => {
      const checkboxes = tbody.querySelectorAll('input[type="checkbox"]');
      checkboxes.forEach(cb => {
        if (cb.checked) {
          const field = cb.dataset.field;
          const value = data[field];
          const inputName = fieldToInputName[field];

          if (inputName) {
            const input = document.querySelector(`[name="${inputName}"]`);
            if (input) input.value = Array.isArray(value) ? value.join(', ') : value;
          }
        }
      });
      overlay.remove();
    });

    popup.appendChild(btnConfirm);
    overlay.appendChild(popup);
    document.body.appendChild(overlay);
  }

  btnImport.addEventListener('click', function() {
    const codice_prodotto = codiceInput.value.trim();
    if (!codice_prodotto) {
      alert('Inserisci un codice prodotto!');
      return;
    }

    const formData = new FormData();
    formData.append('codice_prodotto', codice_prodotto);

    fetch('mouser_import.php', {  // PHP gestisce la chiave API
      method: 'POST',
      body: formData
    })
    .then(resp => resp.json())
    .then(respData => {
      if (respData.success && respData.data) {
        createPopup(respData.data);
      } else {
        console.error('Errore PHP:', respData.error);
        alert('Errore: ' + (respData.error || 'Nessun componente trovato'));
      }
    })
    .catch(err => {
      console.error('Errore fetch:', err);
      alert('Errore fetch');
    });
  });
});
