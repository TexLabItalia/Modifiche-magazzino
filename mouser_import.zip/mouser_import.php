<?php
header('Content-Type: application/json');

$apiKey = "b775b658-a170-470e-9349-6cd04a679138"; // segreta sul server

if (!isset($_POST['codice_prodotto']) || empty($_POST['codice_prodotto'])) {
    echo json_encode(['success' => false, 'error' => 'Nessun codice prodotto']);
    exit;
}

$partNumber = $_POST['codice_prodotto'];

$body = [
    "SearchByPartRequest" => [
        "MouserPartNumber" => $partNumber,
        "Records" => 1
    ]
];

$url = "https://api.mouser.com/api/v1/search/partnumber?apiKey=" . urlencode($apiKey);

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ["Content-Type: application/json"]);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
$response = curl_exec($ch);
curl_close($ch);


$json = json_decode($response, true);
if (!$json) {
    echo json_encode(['success' => false, 'error' => 'Risposta non valida da Mouser']);
    exit;
}

$parts = $json['SearchResults']['Parts'] ?? [];
if (empty($parts)) {
    echo json_encode(['success' => false, 'error' => 'Nessun componente trovato']);
    exit;
}

$part = $parts[0];

// mappatura finale senza scaricare nulla
$mapped = [
    'partNumber'       => $part['ManufacturerPartNumber'] ?? '',
    'manufacturer'     => $part['Manufacturer'] ?? '',
    'description'      => $part['Description'] ?? '',
    'datasheet'        => $part['DataSheetUrl'] ?? '',
    'mouser_image'     => $part['ImagePath'] ?? '',
    'mouser_datasheet' => $part['DataSheetUrl'] ?? ''
];

echo json_encode(['success' => true, 'data' => $mapped]);
